Instrucciones para ejecutar la aplicación GUI_introduction_excercises en Windows:

1. Descomprime el archivo ZIP en una carpeta de tu elección.
2. Navega a la carpeta donde descomprimiste los archivos.
3. Ejecuta el archivo GUI_introduction_excercises.exe para iniciar la aplicación.

Requisitos:
- Sistema operativo: Windows 10 o superior.

Nota: Asegúrate de tener permisos para ejecutar el archivo .exe.
